package Estructuras;

public enum Tipo {
    pelicula,
    funcion,
    cliente,
    sala
}
