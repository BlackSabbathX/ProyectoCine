package Estructuras;

public class Separator {
    public static final String A = "~";
    public static final String B = ";";
}
