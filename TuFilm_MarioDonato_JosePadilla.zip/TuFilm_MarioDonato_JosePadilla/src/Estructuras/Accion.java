package Estructuras;

public enum Accion {
    listar,
    eliminar
}
